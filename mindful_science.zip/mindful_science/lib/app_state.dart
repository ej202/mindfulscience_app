import 'package:flutter/material.dart';
import '/backend/backend.dart';
import '/backend/schema/structs/index.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'flutter_flow/flutter_flow_util.dart';

class FFAppState extends ChangeNotifier {
  static FFAppState _instance = FFAppState._internal();

  factory FFAppState() {
    return _instance;
  }

  FFAppState._internal();

  static void reset() {
    _instance = FFAppState._internal();
  }

  Future initializePersistedState() async {
    prefs = await SharedPreferences.getInstance();
    _safeInit(() {
      _completedLessons =
          prefs.getStringList('ff_completedLessons') ?? _completedLessons;
    });
  }

  void update(VoidCallback callback) {
    callback();
    notifyListeners();
  }

  late SharedPreferences prefs;

  bool _buttonSelected1 = false;
  bool get buttonSelected1 => _buttonSelected1;
  set buttonSelected1(bool value) {
    _buttonSelected1 = value;
  }

  bool _buttonSelected2 = false;
  bool get buttonSelected2 => _buttonSelected2;
  set buttonSelected2(bool value) {
    _buttonSelected2 = value;
  }

  bool _buttonSelected3 = false;
  bool get buttonSelected3 => _buttonSelected3;
  set buttonSelected3(bool value) {
    _buttonSelected3 = value;
  }

  bool _buttonSelected4 = false;
  bool get buttonSelected4 => _buttonSelected4;
  set buttonSelected4(bool value) {
    _buttonSelected4 = value;
  }

  bool _buttonSelected5 = false;
  bool get buttonSelected5 => _buttonSelected5;
  set buttonSelected5(bool value) {
    _buttonSelected5 = value;
  }

  bool _buttonSelected6 = false;
  bool get buttonSelected6 => _buttonSelected6;
  set buttonSelected6(bool value) {
    _buttonSelected6 = value;
  }

  bool _buttonSelected7 = false;
  bool get buttonSelected7 => _buttonSelected7;
  set buttonSelected7(bool value) {
    _buttonSelected7 = value;
  }

  List<String> _completedLessons = [];
  List<String> get completedLessons => _completedLessons;
  set completedLessons(List<String> value) {
    _completedLessons = value;
    prefs.setStringList('ff_completedLessons', value);
  }

  void addToCompletedLessons(String value) {
    completedLessons.add(value);
    prefs.setStringList('ff_completedLessons', _completedLessons);
  }

  void removeFromCompletedLessons(String value) {
    completedLessons.remove(value);
    prefs.setStringList('ff_completedLessons', _completedLessons);
  }

  void removeAtIndexFromCompletedLessons(int index) {
    completedLessons.removeAt(index);
    prefs.setStringList('ff_completedLessons', _completedLessons);
  }

  void updateCompletedLessonsAtIndex(
    int index,
    String Function(String) updateFn,
  ) {
    completedLessons[index] = updateFn(_completedLessons[index]);
    prefs.setStringList('ff_completedLessons', _completedLessons);
  }

  void insertAtIndexInCompletedLessons(int index, String value) {
    completedLessons.insert(index, value);
    prefs.setStringList('ff_completedLessons', _completedLessons);
  }

  bool _isLessonCompleted = false;
  bool get isLessonCompleted => _isLessonCompleted;
  set isLessonCompleted(bool value) {
    _isLessonCompleted = value;
  }

  List<String> _favoritesList = [];
  List<String> get favoritesList => _favoritesList;
  set favoritesList(List<String> value) {
    _favoritesList = value;
  }

  void addToFavoritesList(String value) {
    favoritesList.add(value);
  }

  void removeFromFavoritesList(String value) {
    favoritesList.remove(value);
  }

  void removeAtIndexFromFavoritesList(int index) {
    favoritesList.removeAt(index);
  }

  void updateFavoritesListAtIndex(
    int index,
    String Function(String) updateFn,
  ) {
    favoritesList[index] = updateFn(_favoritesList[index]);
  }

  void insertAtIndexInFavoritesList(int index, String value) {
    favoritesList.insert(index, value);
  }
}

void _safeInit(Function() initializeField) {
  try {
    initializeField();
  } catch (_) {}
}

Future _safeInitAsync(Function() initializeField) async {
  try {
    await initializeField();
  } catch (_) {}
}
