import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/foundation.dart';

Future initFirebase() async {
  if (kIsWeb) {
    await Firebase.initializeApp(
        options: FirebaseOptions(
            apiKey: "AIzaSyAdjx4EpxcH7Di81nCPgsu35gOmDrTwBbc",
            authDomain: "mindful-4c5bd.firebaseapp.com",
            projectId: "mindful-4c5bd",
            storageBucket: "mindful-4c5bd.appspot.com",
            messagingSenderId: "935383203113",
            appId: "1:935383203113:web:65d1a58a8a2df67879cb38",
            measurementId: "G-P8BHE830TE"));
  } else {
    await Firebase.initializeApp();
  }
}
