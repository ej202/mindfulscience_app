import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class CoursesRecord extends FirestoreRecord {
  CoursesRecord._(
    DocumentReference reference,
    Map<String, dynamic> data,
  ) : super(reference, data) {
    _initializeFields();
  }

  // "courseTitle" field.
  String? _courseTitle;
  String get courseTitle => _courseTitle ?? '';
  bool hasCourseTitle() => _courseTitle != null;

  // "courseDescription" field.
  String? _courseDescription;
  String get courseDescription => _courseDescription ?? '';
  bool hasCourseDescription() => _courseDescription != null;

  // "courseSessions" field.
  String? _courseSessions;
  String get courseSessions => _courseSessions ?? '';
  bool hasCourseSessions() => _courseSessions != null;

  // "order" field.
  int? _order;
  int get order => _order ?? 0;
  bool hasOrder() => _order != null;

  // "courseAudioUrl" field.
  String? _courseAudioUrl;
  String get courseAudioUrl => _courseAudioUrl ?? '';
  bool hasCourseAudioUrl() => _courseAudioUrl != null;

  // "isLocked" field.
  bool? _isLocked;
  bool get isLocked => _isLocked ?? false;
  bool hasIsLocked() => _isLocked != null;

  // "isFavorite" field.
  bool? _isFavorite;
  bool get isFavorite => _isFavorite ?? false;
  bool hasIsFavorite() => _isFavorite != null;

  // "courseImageUrl" field.
  String? _courseImageUrl;
  String get courseImageUrl => _courseImageUrl ?? '';
  bool hasCourseImageUrl() => _courseImageUrl != null;

  // "courseCategory" field.
  String? _courseCategory;
  String get courseCategory => _courseCategory ?? '';
  bool hasCourseCategory() => _courseCategory != null;

  // "courseid" field.
  int? _courseid;
  int get courseid => _courseid ?? 0;
  bool hasCourseid() => _courseid != null;

  void _initializeFields() {
    _courseTitle = snapshotData['courseTitle'] as String?;
    _courseDescription = snapshotData['courseDescription'] as String?;
    _courseSessions = snapshotData['courseSessions'] as String?;
    _order = castToType<int>(snapshotData['order']);
    _courseAudioUrl = snapshotData['courseAudioUrl'] as String?;
    _isLocked = snapshotData['isLocked'] as bool?;
    _isFavorite = snapshotData['isFavorite'] as bool?;
    _courseImageUrl = snapshotData['courseImageUrl'] as String?;
    _courseCategory = snapshotData['courseCategory'] as String?;
    _courseid = castToType<int>(snapshotData['courseid']);
  }

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('courses');

  static Stream<CoursesRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => CoursesRecord.fromSnapshot(s));

  static Future<CoursesRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => CoursesRecord.fromSnapshot(s));

  static CoursesRecord fromSnapshot(DocumentSnapshot snapshot) =>
      CoursesRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static CoursesRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      CoursesRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'CoursesRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is CoursesRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createCoursesRecordData({
  String? courseTitle,
  String? courseDescription,
  String? courseSessions,
  int? order,
  String? courseAudioUrl,
  bool? isLocked,
  bool? isFavorite,
  String? courseImageUrl,
  String? courseCategory,
  int? courseid,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'courseTitle': courseTitle,
      'courseDescription': courseDescription,
      'courseSessions': courseSessions,
      'order': order,
      'courseAudioUrl': courseAudioUrl,
      'isLocked': isLocked,
      'isFavorite': isFavorite,
      'courseImageUrl': courseImageUrl,
      'courseCategory': courseCategory,
      'courseid': courseid,
    }.withoutNulls,
  );

  return firestoreData;
}

class CoursesRecordDocumentEquality implements Equality<CoursesRecord> {
  const CoursesRecordDocumentEquality();

  @override
  bool equals(CoursesRecord? e1, CoursesRecord? e2) {
    return e1?.courseTitle == e2?.courseTitle &&
        e1?.courseDescription == e2?.courseDescription &&
        e1?.courseSessions == e2?.courseSessions &&
        e1?.order == e2?.order &&
        e1?.courseAudioUrl == e2?.courseAudioUrl &&
        e1?.isLocked == e2?.isLocked &&
        e1?.isFavorite == e2?.isFavorite &&
        e1?.courseImageUrl == e2?.courseImageUrl &&
        e1?.courseCategory == e2?.courseCategory &&
        e1?.courseid == e2?.courseid;
  }

  @override
  int hash(CoursesRecord? e) => const ListEquality().hash([
        e?.courseTitle,
        e?.courseDescription,
        e?.courseSessions,
        e?.order,
        e?.courseAudioUrl,
        e?.isLocked,
        e?.isFavorite,
        e?.courseImageUrl,
        e?.courseCategory,
        e?.courseid
      ]);

  @override
  bool isValidKey(Object? o) => o is CoursesRecord;
}
