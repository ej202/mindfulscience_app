import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class DailyQuotesRecord extends FirestoreRecord {
  DailyQuotesRecord._(
    DocumentReference reference,
    Map<String, dynamic> data,
  ) : super(reference, data) {
    _initializeFields();
  }

  // "dayNumber" field.
  int? _dayNumber;
  int get dayNumber => _dayNumber ?? 0;
  bool hasDayNumber() => _dayNumber != null;

  // "quote" field.
  String? _quote;
  String get quote => _quote ?? '';
  bool hasQuote() => _quote != null;

  // "author" field.
  String? _author;
  String get author => _author ?? '';
  bool hasAuthor() => _author != null;

  void _initializeFields() {
    _dayNumber = castToType<int>(snapshotData['dayNumber']);
    _quote = snapshotData['quote'] as String?;
    _author = snapshotData['author'] as String?;
  }

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('daily_quotes');

  static Stream<DailyQuotesRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => DailyQuotesRecord.fromSnapshot(s));

  static Future<DailyQuotesRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => DailyQuotesRecord.fromSnapshot(s));

  static DailyQuotesRecord fromSnapshot(DocumentSnapshot snapshot) =>
      DailyQuotesRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static DailyQuotesRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      DailyQuotesRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'DailyQuotesRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is DailyQuotesRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createDailyQuotesRecordData({
  int? dayNumber,
  String? quote,
  String? author,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'dayNumber': dayNumber,
      'quote': quote,
      'author': author,
    }.withoutNulls,
  );

  return firestoreData;
}

class DailyQuotesRecordDocumentEquality implements Equality<DailyQuotesRecord> {
  const DailyQuotesRecordDocumentEquality();

  @override
  bool equals(DailyQuotesRecord? e1, DailyQuotesRecord? e2) {
    return e1?.dayNumber == e2?.dayNumber &&
        e1?.quote == e2?.quote &&
        e1?.author == e2?.author;
  }

  @override
  int hash(DailyQuotesRecord? e) =>
      const ListEquality().hash([e?.dayNumber, e?.quote, e?.author]);

  @override
  bool isValidKey(Object? o) => o is DailyQuotesRecord;
}
