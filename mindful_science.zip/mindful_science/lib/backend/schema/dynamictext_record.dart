import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class DynamictextRecord extends FirestoreRecord {
  DynamictextRecord._(
    DocumentReference reference,
    Map<String, dynamic> data,
  ) : super(reference, data) {
    _initializeFields();
  }

  // "section1" field.
  String? _section1;
  String get section1 => _section1 ?? '';
  bool hasSection1() => _section1 != null;

  // "section2" field.
  String? _section2;
  String get section2 => _section2 ?? '';
  bool hasSection2() => _section2 != null;

  // "section3" field.
  String? _section3;
  String get section3 => _section3 ?? '';
  bool hasSection3() => _section3 != null;

  void _initializeFields() {
    _section1 = snapshotData['section1'] as String?;
    _section2 = snapshotData['section2'] as String?;
    _section3 = snapshotData['section3'] as String?;
  }

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('dynamictext');

  static Stream<DynamictextRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => DynamictextRecord.fromSnapshot(s));

  static Future<DynamictextRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => DynamictextRecord.fromSnapshot(s));

  static DynamictextRecord fromSnapshot(DocumentSnapshot snapshot) =>
      DynamictextRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static DynamictextRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      DynamictextRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'DynamictextRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is DynamictextRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createDynamictextRecordData({
  String? section1,
  String? section2,
  String? section3,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'section1': section1,
      'section2': section2,
      'section3': section3,
    }.withoutNulls,
  );

  return firestoreData;
}

class DynamictextRecordDocumentEquality implements Equality<DynamictextRecord> {
  const DynamictextRecordDocumentEquality();

  @override
  bool equals(DynamictextRecord? e1, DynamictextRecord? e2) {
    return e1?.section1 == e2?.section1 &&
        e1?.section2 == e2?.section2 &&
        e1?.section3 == e2?.section3;
  }

  @override
  int hash(DynamictextRecord? e) =>
      const ListEquality().hash([e?.section1, e?.section2, e?.section3]);

  @override
  bool isValidKey(Object? o) => o is DynamictextRecord;
}
