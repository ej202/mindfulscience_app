import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class LessonsRecord extends FirestoreRecord {
  LessonsRecord._(
    DocumentReference reference,
    Map<String, dynamic> data,
  ) : super(reference, data) {
    _initializeFields();
  }

  // "lessonTitle" field.
  String? _lessonTitle;
  String get lessonTitle => _lessonTitle ?? '';
  bool hasLessonTitle() => _lessonTitle != null;

  // "lessonDuration" field.
  String? _lessonDuration;
  String get lessonDuration => _lessonDuration ?? '';
  bool hasLessonDuration() => _lessonDuration != null;

  // "order" field.
  int? _order;
  int get order => _order ?? 0;
  bool hasOrder() => _order != null;

  // "isLocked" field.
  bool? _isLocked;
  bool get isLocked => _isLocked ?? false;
  bool hasIsLocked() => _isLocked != null;

  // "lessonAudioUrl" field.
  String? _lessonAudioUrl;
  String get lessonAudioUrl => _lessonAudioUrl ?? '';
  bool hasLessonAudioUrl() => _lessonAudioUrl != null;

  // "isFavorite" field.
  bool? _isFavorite;
  bool get isFavorite => _isFavorite ?? false;
  bool hasIsFavorite() => _isFavorite != null;

  // "courseid" field.
  int? _courseid;
  int get courseid => _courseid ?? 0;
  bool hasCourseid() => _courseid != null;

  // "lessonCategory" field.
  String? _lessonCategory;
  String get lessonCategory => _lessonCategory ?? '';
  bool hasLessonCategory() => _lessonCategory != null;

  // "lessonImageUrl" field.
  String? _lessonImageUrl;
  String get lessonImageUrl => _lessonImageUrl ?? '';
  bool hasLessonImageUrl() => _lessonImageUrl != null;

  // "lessonNum" field.
  String? _lessonNum;
  String get lessonNum => _lessonNum ?? '';
  bool hasLessonNum() => _lessonNum != null;

  // "lessonid" field.
  int? _lessonid;
  int get lessonid => _lessonid ?? 0;
  bool hasLessonid() => _lessonid != null;

  DocumentReference get parentReference => reference.parent.parent!;

  void _initializeFields() {
    _lessonTitle = snapshotData['lessonTitle'] as String?;
    _lessonDuration = snapshotData['lessonDuration'] as String?;
    _order = castToType<int>(snapshotData['order']);
    _isLocked = snapshotData['isLocked'] as bool?;
    _lessonAudioUrl = snapshotData['lessonAudioUrl'] as String?;
    _isFavorite = snapshotData['isFavorite'] as bool?;
    _courseid = castToType<int>(snapshotData['courseid']);
    _lessonCategory = snapshotData['lessonCategory'] as String?;
    _lessonImageUrl = snapshotData['lessonImageUrl'] as String?;
    _lessonNum = snapshotData['lessonNum'] as String?;
    _lessonid = castToType<int>(snapshotData['lessonid']);
  }

  static Query<Map<String, dynamic>> collection([DocumentReference? parent]) =>
      parent != null
          ? parent.collection('lessons')
          : FirebaseFirestore.instance.collectionGroup('lessons');

  static DocumentReference createDoc(DocumentReference parent, {String? id}) =>
      parent.collection('lessons').doc(id);

  static Stream<LessonsRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => LessonsRecord.fromSnapshot(s));

  static Future<LessonsRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => LessonsRecord.fromSnapshot(s));

  static LessonsRecord fromSnapshot(DocumentSnapshot snapshot) =>
      LessonsRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static LessonsRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      LessonsRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'LessonsRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is LessonsRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createLessonsRecordData({
  String? lessonTitle,
  String? lessonDuration,
  int? order,
  bool? isLocked,
  String? lessonAudioUrl,
  bool? isFavorite,
  int? courseid,
  String? lessonCategory,
  String? lessonImageUrl,
  String? lessonNum,
  int? lessonid,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'lessonTitle': lessonTitle,
      'lessonDuration': lessonDuration,
      'order': order,
      'isLocked': isLocked,
      'lessonAudioUrl': lessonAudioUrl,
      'isFavorite': isFavorite,
      'courseid': courseid,
      'lessonCategory': lessonCategory,
      'lessonImageUrl': lessonImageUrl,
      'lessonNum': lessonNum,
      'lessonid': lessonid,
    }.withoutNulls,
  );

  return firestoreData;
}

class LessonsRecordDocumentEquality implements Equality<LessonsRecord> {
  const LessonsRecordDocumentEquality();

  @override
  bool equals(LessonsRecord? e1, LessonsRecord? e2) {
    return e1?.lessonTitle == e2?.lessonTitle &&
        e1?.lessonDuration == e2?.lessonDuration &&
        e1?.order == e2?.order &&
        e1?.isLocked == e2?.isLocked &&
        e1?.lessonAudioUrl == e2?.lessonAudioUrl &&
        e1?.isFavorite == e2?.isFavorite &&
        e1?.courseid == e2?.courseid &&
        e1?.lessonCategory == e2?.lessonCategory &&
        e1?.lessonImageUrl == e2?.lessonImageUrl &&
        e1?.lessonNum == e2?.lessonNum &&
        e1?.lessonid == e2?.lessonid;
  }

  @override
  int hash(LessonsRecord? e) => const ListEquality().hash([
        e?.lessonTitle,
        e?.lessonDuration,
        e?.order,
        e?.isLocked,
        e?.lessonAudioUrl,
        e?.isFavorite,
        e?.courseid,
        e?.lessonCategory,
        e?.lessonImageUrl,
        e?.lessonNum,
        e?.lessonid
      ]);

  @override
  bool isValidKey(Object? o) => o is LessonsRecord;
}
