import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class SinglesRecord extends FirestoreRecord {
  SinglesRecord._(
    DocumentReference reference,
    Map<String, dynamic> data,
  ) : super(reference, data) {
    _initializeFields();
  }

  // "singletitle" field.
  String? _singletitle;
  String get singletitle => _singletitle ?? '';
  bool hasSingletitle() => _singletitle != null;

  // "singleDuration" field.
  String? _singleDuration;
  String get singleDuration => _singleDuration ?? '';
  bool hasSingleDuration() => _singleDuration != null;

  // "singleImageUrl" field.
  String? _singleImageUrl;
  String get singleImageUrl => _singleImageUrl ?? '';
  bool hasSingleImageUrl() => _singleImageUrl != null;

  // "lessonAudioUrl" field.
  String? _lessonAudioUrl;
  String get lessonAudioUrl => _lessonAudioUrl ?? '';
  bool hasLessonAudioUrl() => _lessonAudioUrl != null;

  // "isLocked" field.
  bool? _isLocked;
  bool get isLocked => _isLocked ?? false;
  bool hasIsLocked() => _isLocked != null;

  // "isFavorite" field.
  bool? _isFavorite;
  bool get isFavorite => _isFavorite ?? false;
  bool hasIsFavorite() => _isFavorite != null;

  // "singleCategory" field.
  String? _singleCategory;
  String get singleCategory => _singleCategory ?? '';
  bool hasSingleCategory() => _singleCategory != null;

  // "singleID" field.
  int? _singleID;
  int get singleID => _singleID ?? 0;
  bool hasSingleID() => _singleID != null;

  void _initializeFields() {
    _singletitle = snapshotData['singletitle'] as String?;
    _singleDuration = snapshotData['singleDuration'] as String?;
    _singleImageUrl = snapshotData['singleImageUrl'] as String?;
    _lessonAudioUrl = snapshotData['lessonAudioUrl'] as String?;
    _isLocked = snapshotData['isLocked'] as bool?;
    _isFavorite = snapshotData['isFavorite'] as bool?;
    _singleCategory = snapshotData['singleCategory'] as String?;
    _singleID = castToType<int>(snapshotData['singleID']);
  }

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('singles');

  static Stream<SinglesRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => SinglesRecord.fromSnapshot(s));

  static Future<SinglesRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => SinglesRecord.fromSnapshot(s));

  static SinglesRecord fromSnapshot(DocumentSnapshot snapshot) =>
      SinglesRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static SinglesRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      SinglesRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'SinglesRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is SinglesRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createSinglesRecordData({
  String? singletitle,
  String? singleDuration,
  String? singleImageUrl,
  String? lessonAudioUrl,
  bool? isLocked,
  bool? isFavorite,
  String? singleCategory,
  int? singleID,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'singletitle': singletitle,
      'singleDuration': singleDuration,
      'singleImageUrl': singleImageUrl,
      'lessonAudioUrl': lessonAudioUrl,
      'isLocked': isLocked,
      'isFavorite': isFavorite,
      'singleCategory': singleCategory,
      'singleID': singleID,
    }.withoutNulls,
  );

  return firestoreData;
}

class SinglesRecordDocumentEquality implements Equality<SinglesRecord> {
  const SinglesRecordDocumentEquality();

  @override
  bool equals(SinglesRecord? e1, SinglesRecord? e2) {
    return e1?.singletitle == e2?.singletitle &&
        e1?.singleDuration == e2?.singleDuration &&
        e1?.singleImageUrl == e2?.singleImageUrl &&
        e1?.lessonAudioUrl == e2?.lessonAudioUrl &&
        e1?.isLocked == e2?.isLocked &&
        e1?.isFavorite == e2?.isFavorite &&
        e1?.singleCategory == e2?.singleCategory &&
        e1?.singleID == e2?.singleID;
  }

  @override
  int hash(SinglesRecord? e) => const ListEquality().hash([
        e?.singletitle,
        e?.singleDuration,
        e?.singleImageUrl,
        e?.lessonAudioUrl,
        e?.isLocked,
        e?.isFavorite,
        e?.singleCategory,
        e?.singleID
      ]);

  @override
  bool isValidKey(Object? o) => o is SinglesRecord;
}
