// ignore_for_file: unnecessary_getters_setters

import 'package:cloud_firestore/cloud_firestore.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class RecentlyPlayedItemStruct extends FFFirebaseStruct {
  RecentlyPlayedItemStruct({
    String? title,
    String? type,
    FirestoreUtilData firestoreUtilData = const FirestoreUtilData(),
  })  : _title = title,
        _type = type,
        super(firestoreUtilData);

  // "title" field.
  String? _title;
  String get title => _title ?? '';
  set title(String? val) => _title = val;

  bool hasTitle() => _title != null;

  // "type" field.
  String? _type;
  String get type => _type ?? '';
  set type(String? val) => _type = val;

  bool hasType() => _type != null;

  static RecentlyPlayedItemStruct fromMap(Map<String, dynamic> data) =>
      RecentlyPlayedItemStruct(
        title: data['title'] as String?,
        type: data['type'] as String?,
      );

  static RecentlyPlayedItemStruct? maybeFromMap(dynamic data) => data is Map
      ? RecentlyPlayedItemStruct.fromMap(data.cast<String, dynamic>())
      : null;

  Map<String, dynamic> toMap() => {
        'title': _title,
        'type': _type,
      }.withoutNulls;

  @override
  Map<String, dynamic> toSerializableMap() => {
        'title': serializeParam(
          _title,
          ParamType.String,
        ),
        'type': serializeParam(
          _type,
          ParamType.String,
        ),
      }.withoutNulls;

  static RecentlyPlayedItemStruct fromSerializableMap(
          Map<String, dynamic> data) =>
      RecentlyPlayedItemStruct(
        title: deserializeParam(
          data['title'],
          ParamType.String,
          false,
        ),
        type: deserializeParam(
          data['type'],
          ParamType.String,
          false,
        ),
      );

  @override
  String toString() => 'RecentlyPlayedItemStruct(${toMap()})';

  @override
  bool operator ==(Object other) {
    return other is RecentlyPlayedItemStruct &&
        title == other.title &&
        type == other.type;
  }

  @override
  int get hashCode => const ListEquality().hash([title, type]);
}

RecentlyPlayedItemStruct createRecentlyPlayedItemStruct({
  String? title,
  String? type,
  Map<String, dynamic> fieldValues = const {},
  bool clearUnsetFields = true,
  bool create = false,
  bool delete = false,
}) =>
    RecentlyPlayedItemStruct(
      title: title,
      type: type,
      firestoreUtilData: FirestoreUtilData(
        clearUnsetFields: clearUnsetFields,
        create: create,
        delete: delete,
        fieldValues: fieldValues,
      ),
    );

RecentlyPlayedItemStruct? updateRecentlyPlayedItemStruct(
  RecentlyPlayedItemStruct? recentlyPlayedItem, {
  bool clearUnsetFields = true,
  bool create = false,
}) =>
    recentlyPlayedItem
      ?..firestoreUtilData = FirestoreUtilData(
        clearUnsetFields: clearUnsetFields,
        create: create,
      );

void addRecentlyPlayedItemStructData(
  Map<String, dynamic> firestoreData,
  RecentlyPlayedItemStruct? recentlyPlayedItem,
  String fieldName, [
  bool forFieldValue = false,
]) {
  firestoreData.remove(fieldName);
  if (recentlyPlayedItem == null) {
    return;
  }
  if (recentlyPlayedItem.firestoreUtilData.delete) {
    firestoreData[fieldName] = FieldValue.delete();
    return;
  }
  final clearFields =
      !forFieldValue && recentlyPlayedItem.firestoreUtilData.clearUnsetFields;
  if (clearFields) {
    firestoreData[fieldName] = <String, dynamic>{};
  }
  final recentlyPlayedItemData =
      getRecentlyPlayedItemFirestoreData(recentlyPlayedItem, forFieldValue);
  final nestedData =
      recentlyPlayedItemData.map((k, v) => MapEntry('$fieldName.$k', v));

  final mergeFields =
      recentlyPlayedItem.firestoreUtilData.create || clearFields;
  firestoreData
      .addAll(mergeFields ? mergeNestedFields(nestedData) : nestedData);
}

Map<String, dynamic> getRecentlyPlayedItemFirestoreData(
  RecentlyPlayedItemStruct? recentlyPlayedItem, [
  bool forFieldValue = false,
]) {
  if (recentlyPlayedItem == null) {
    return {};
  }
  final firestoreData = mapToFirestore(recentlyPlayedItem.toMap());

  // Add any Firestore field values
  recentlyPlayedItem.firestoreUtilData.fieldValues
      .forEach((k, v) => firestoreData[k] = v);

  return forFieldValue ? mergeNestedFields(firestoreData) : firestoreData;
}

List<Map<String, dynamic>> getRecentlyPlayedItemListFirestoreData(
  List<RecentlyPlayedItemStruct>? recentlyPlayedItems,
) =>
    recentlyPlayedItems
        ?.map((e) => getRecentlyPlayedItemFirestoreData(e, true))
        .toList() ??
    [];
