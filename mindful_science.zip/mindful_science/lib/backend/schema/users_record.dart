import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class UsersRecord extends FirestoreRecord {
  UsersRecord._(
    DocumentReference reference,
    Map<String, dynamic> data,
  ) : super(reference, data) {
    _initializeFields();
  }

  // "email" field.
  String? _email;
  String get email => _email ?? '';
  bool hasEmail() => _email != null;

  // "first_name" field.
  String? _firstName;
  String get firstName => _firstName ?? '';
  bool hasFirstName() => _firstName != null;

  // "profile_picture" field.
  String? _profilePicture;
  String get profilePicture => _profilePicture ?? '';
  bool hasProfilePicture() => _profilePicture != null;

  // "hasPremium" field.
  bool? _hasPremium;
  bool get hasPremium => _hasPremium ?? false;
  bool hasHasPremium() => _hasPremium != null;

  // "display_name" field.
  String? _displayName;
  String get displayName => _displayName ?? '';
  bool hasDisplayName() => _displayName != null;

  // "photo_url" field.
  String? _photoUrl;
  String get photoUrl => _photoUrl ?? '';
  bool hasPhotoUrl() => _photoUrl != null;

  // "uid" field.
  String? _uid;
  String get uid => _uid ?? '';
  bool hasUid() => _uid != null;

  // "created_time" field.
  DateTime? _createdTime;
  DateTime? get createdTime => _createdTime;
  bool hasCreatedTime() => _createdTime != null;

  // "phone_number" field.
  String? _phoneNumber;
  String get phoneNumber => _phoneNumber ?? '';
  bool hasPhoneNumber() => _phoneNumber != null;

  // "completedLessons" field.
  List<String>? _completedLessons;
  List<String> get completedLessons => _completedLessons ?? const [];
  bool hasCompletedLessons() => _completedLessons != null;

  // "favorites" field.
  List<int>? _favorites;
  List<int> get favorites => _favorites ?? const [];
  bool hasFavorites() => _favorites != null;

  // "favorite_courses" field.
  List<int>? _favoriteCourses;
  List<int> get favoriteCourses => _favoriteCourses ?? const [];
  bool hasFavoriteCourses() => _favoriteCourses != null;

  // "recently_played" field.
  List<RecentlyPlayedItemStruct>? _recentlyPlayed;
  List<RecentlyPlayedItemStruct> get recentlyPlayed =>
      _recentlyPlayed ?? const [];
  bool hasRecentlyPlayed() => _recentlyPlayed != null;

  // "favorite_singles" field.
  List<int>? _favoriteSingles;
  List<int> get favoriteSingles => _favoriteSingles ?? const [];
  bool hasFavoriteSingles() => _favoriteSingles != null;

  // "favorite_lessons" field.
  List<int>? _favoriteLessons;
  List<int> get favoriteLessons => _favoriteLessons ?? const [];
  bool hasFavoriteLessons() => _favoriteLessons != null;

  void _initializeFields() {
    _email = snapshotData['email'] as String?;
    _firstName = snapshotData['first_name'] as String?;
    _profilePicture = snapshotData['profile_picture'] as String?;
    _hasPremium = snapshotData['hasPremium'] as bool?;
    _displayName = snapshotData['display_name'] as String?;
    _photoUrl = snapshotData['photo_url'] as String?;
    _uid = snapshotData['uid'] as String?;
    _createdTime = snapshotData['created_time'] as DateTime?;
    _phoneNumber = snapshotData['phone_number'] as String?;
    _completedLessons = getDataList(snapshotData['completedLessons']);
    _favorites = getDataList(snapshotData['favorites']);
    _favoriteCourses = getDataList(snapshotData['favorite_courses']);
    _recentlyPlayed = getStructList(
      snapshotData['recently_played'],
      RecentlyPlayedItemStruct.fromMap,
    );
    _favoriteSingles = getDataList(snapshotData['favorite_singles']);
    _favoriteLessons = getDataList(snapshotData['favorite_lessons']);
  }

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('users');

  static Stream<UsersRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => UsersRecord.fromSnapshot(s));

  static Future<UsersRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => UsersRecord.fromSnapshot(s));

  static UsersRecord fromSnapshot(DocumentSnapshot snapshot) => UsersRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static UsersRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      UsersRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'UsersRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is UsersRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createUsersRecordData({
  String? email,
  String? firstName,
  String? profilePicture,
  bool? hasPremium,
  String? displayName,
  String? photoUrl,
  String? uid,
  DateTime? createdTime,
  String? phoneNumber,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'email': email,
      'first_name': firstName,
      'profile_picture': profilePicture,
      'hasPremium': hasPremium,
      'display_name': displayName,
      'photo_url': photoUrl,
      'uid': uid,
      'created_time': createdTime,
      'phone_number': phoneNumber,
    }.withoutNulls,
  );

  return firestoreData;
}

class UsersRecordDocumentEquality implements Equality<UsersRecord> {
  const UsersRecordDocumentEquality();

  @override
  bool equals(UsersRecord? e1, UsersRecord? e2) {
    const listEquality = ListEquality();
    return e1?.email == e2?.email &&
        e1?.firstName == e2?.firstName &&
        e1?.profilePicture == e2?.profilePicture &&
        e1?.hasPremium == e2?.hasPremium &&
        e1?.displayName == e2?.displayName &&
        e1?.photoUrl == e2?.photoUrl &&
        e1?.uid == e2?.uid &&
        e1?.createdTime == e2?.createdTime &&
        e1?.phoneNumber == e2?.phoneNumber &&
        listEquality.equals(e1?.completedLessons, e2?.completedLessons) &&
        listEquality.equals(e1?.favorites, e2?.favorites) &&
        listEquality.equals(e1?.favoriteCourses, e2?.favoriteCourses) &&
        listEquality.equals(e1?.recentlyPlayed, e2?.recentlyPlayed) &&
        listEquality.equals(e1?.favoriteSingles, e2?.favoriteSingles) &&
        listEquality.equals(e1?.favoriteLessons, e2?.favoriteLessons);
  }

  @override
  int hash(UsersRecord? e) => const ListEquality().hash([
        e?.email,
        e?.firstName,
        e?.profilePicture,
        e?.hasPremium,
        e?.displayName,
        e?.photoUrl,
        e?.uid,
        e?.createdTime,
        e?.phoneNumber,
        e?.completedLessons,
        e?.favorites,
        e?.favoriteCourses,
        e?.recentlyPlayed,
        e?.favoriteSingles,
        e?.favoriteLessons
      ]);

  @override
  bool isValidKey(Object? o) => o is UsersRecord;
}
