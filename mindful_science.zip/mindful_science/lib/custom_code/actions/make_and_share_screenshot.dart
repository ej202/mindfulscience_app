// Automatic FlutterFlow imports
import '/backend/backend.dart';
import '/backend/schema/structs/index.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'index.dart'; // Imports other custom actions
import '/flutter_flow/custom_functions.dart'; // Imports custom functions
import 'package:flutter/material.dart';
// Begin custom action code
// DO NOT REMOVE OR MODIFY THE CODE ABOVE!

import '/flutter_flow/custom_functions.dart';

import 'package:cross_file/cross_file.dart';
import 'package:flutter_native_screenshot/flutter_native_screenshot.dart';
import 'package:path_provider/path_provider.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:share_plus/share_plus.dart';
import 'dart:io';

Future<bool> makeAndShareScreenshot(BuildContext context) async {
  final resultPermission = await Permission.manageExternalStorage.request();

  if (resultPermission != PermissionStatus.granted) return false;

  final path = await FlutterNativeScreenshot.takeScreenshot();
  if (path == null || path.isEmpty) {
    print("Screenshot failed");
    return false;
  }

  final destinationFile =
      '${(await getTemporaryDirectory()).path}/screenshot.png';
  final sourceFile = File(path);

  try {
    await sourceFile.rename(destinationFile);
  } catch (e) {
    await sourceFile.copy(destinationFile);
    await sourceFile.delete();
  }

  await Share.shareXFiles([XFile(destinationFile)]);
  return true;
}
