// Automatic FlutterFlow imports
import '/backend/backend.dart';
import '/backend/schema/structs/index.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'index.dart'; // Imports other custom widgets
import '/custom_code/actions/index.dart'; // Imports custom actions
import '/flutter_flow/custom_functions.dart'; // Imports custom functions
import 'package:flutter/material.dart';
// Begin custom widget code
// DO NOT REMOVE OR MODIFY THE CODE ABOVE!

import 'package:audio_session/audio_session.dart';
import 'package:just_audio/just_audio.dart';
import 'package:rxdart/rxdart.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class AudioWidget extends StatefulWidget {
  final double? width;
  final double? height;
  final String? audioUrl;
  final String? lessonTitle;
  final String?
      collectionType; // if set, store {title, type} in "recently_played"
  final Color? backgroundColor;
  final double? iconSize;
  final Color? iconColor;
  final double? buttonSpacing;

  const AudioWidget({
    Key? key,
    this.width,
    this.height,
    this.audioUrl,
    this.lessonTitle,
    this.collectionType,
    this.backgroundColor,
    this.iconSize,
    this.iconColor,
    this.buttonSpacing,
  }) : super(key: key);

  @override
  State<AudioWidget> createState() => _AudioWidgetState();
}

class _AudioWidgetState extends State<AudioWidget> {
  final _player = AudioPlayer();
  bool isLoading = true;
  bool isPlaying = false;

  @override
  void initState() {
    super.initState();
    _init();

    // Listen for changes in the player's state
    _player.playerStateStream.listen((state) {
      setState(() => isPlaying = state.playing);

      // If audio finished playing
      if (state.processingState == ProcessingState.completed) {
        if (mounted && widget.lessonTitle != null) {
          print("✅ Audio Completed -> Marking lesson + navigate back.");

          // Wait for Firestore update, then back
          _markLessonCompleted(widget.lessonTitle!).then((_) {
            _navigateBackWithDelay();
          });
        }
      }
    });
  }

  /// Initialize the audio session & set audio
  Future<void> _init() async {
    final session = await AudioSession.instance;
    await session.configure(const AudioSessionConfiguration.speech());

    try {
      await _player.setAudioSource(
        AudioSource.uri(Uri.parse(widget.audioUrl!)),
      );
    } catch (e) {
      print("Error loading audio source: $e");
    }

    if (mounted) {
      setState(() => isLoading = false);
    }
  }

  /// Immediately add to recently_played as soon as user taps Play
  Future<void> _addRecentlyPlayed(String lessonTitle) async {
    print("⭐ Updating 'recently_played' immediately...");
    final user = FirebaseAuth.instance.currentUser;
    if (user == null) return;

    final userEmail = user.email;
    if (userEmail == null) return;

    final query = await FirebaseFirestore.instance
        .collection('users')
        .where('email', isEqualTo: userEmail)
        .limit(1)
        .get();

    if (query.docs.isEmpty) {
      print("No user doc for $userEmail");
      return;
    }

    final userDocRef = query.docs.first.reference;

    try {
      if (widget.collectionType != null && widget.collectionType!.isNotEmpty) {
        final item = {
          "title": lessonTitle,
          "type": widget.collectionType,
        };
        await userDocRef.update({
          'recently_played': FieldValue.arrayUnion([item])
        });
        print("✅ recently_played updated with: $item");
      } else {
        await userDocRef.update({
          'recently_played': FieldValue.arrayUnion([lessonTitle])
        });
        print("✅ recently_played updated with title: $lessonTitle");
      }
    } catch (e) {
      print("Error updating recently_played: $e");
    }
  }

  /// Mark a lesson as completed in Firestore
  Future<void> _markLessonCompleted(String lessonTitle) async {
    print("⭐ Marking lesson completed: $lessonTitle");
    final user = FirebaseAuth.instance.currentUser;
    if (user == null) return;

    final userEmail = user.email;
    if (userEmail == null) return;

    final query = await FirebaseFirestore.instance
        .collection('users')
        .where('email', isEqualTo: userEmail)
        .limit(1)
        .get();

    if (query.docs.isEmpty) {
      print("No user doc for $userEmail (can't mark complete)");
      return;
    }

    final userDocRef = query.docs.first.reference;

    try {
      await userDocRef.update({
        'completedLessons': FieldValue.arrayUnion([lessonTitle])
      });
      print("✅ Lesson completed for $userEmail");
    } catch (e) {
      print("Error marking lesson complete: $e");
    }
  }

  /// After a short delay, pop the route if possible
  void _navigateBackWithDelay() {
    Future.delayed(const Duration(milliseconds: 500), () {
      if (mounted && Navigator.canPop(context)) {
        Navigator.pop(context);
      }
    });
  }

  @override
  void dispose() {
    _player.dispose();
    super.dispose();
  }

  /// Combined stream of position, bufferedPosition, total duration
  Stream<PositionData> get _positionDataStream =>
      Rx.combineLatest3<Duration, Duration, Duration?, PositionData>(
        _player.positionStream,
        _player.bufferedPositionStream,
        _player.durationStream,
        (position, bufferedPosition, duration) =>
            PositionData(position, bufferedPosition, duration ?? Duration.zero),
      );

  /// Helper to format a Duration as mm:ss
  String _formatDuration(Duration duration) {
    String twoDigits(int n) => n.toString().padLeft(2, '0');
    return "${twoDigits(duration.inMinutes)}:${twoDigits(duration.inSeconds.remainder(60))}";
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      color: widget.backgroundColor ?? Colors.transparent,
      width: widget.width,
      height: widget.height,
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          if (isLoading) const CircularProgressIndicator(),
          if (!isLoading)
            Column(
              children: [
                // Row of controls
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    IconButton(
                      icon: Icon(
                        Icons.replay_10,
                        color: widget.iconColor ?? Colors.white,
                        size: widget.iconSize ?? 40,
                      ),
                      onPressed: () {
                        final pos = _player.position;
                        _player.seek(pos - const Duration(seconds: 10));
                      },
                    ),
                    SizedBox(width: widget.buttonSpacing ?? 20),
                    GestureDetector(
                      onTap: () async {
                        if (isPlaying) {
                          // Already playing -> user wants to pause
                          await _player.pause();
                        } else {
                          // Currently paused -> user wants to play
                          // 1) Immediately update 'recently_played'
                          if (widget.lessonTitle != null) {
                            await _addRecentlyPlayed(widget.lessonTitle!);
                          }
                          // 2) Start playback
                          await _player.play();
                        }
                        // Rebuild UI to show new icon
                        setState(() {});
                      },
                      child: CircleAvatar(
                        radius: widget.iconSize ?? 35,
                        backgroundColor: widget.iconColor ?? Colors.white,
                        child: Icon(
                          isPlaying ? Icons.pause : Icons.play_arrow,
                          color: Colors.black,
                          size: widget.iconSize ?? 40,
                        ),
                      ),
                    ),
                    SizedBox(width: widget.buttonSpacing ?? 20),
                    IconButton(
                      icon: Icon(
                        Icons.forward_10,
                        color: widget.iconColor ?? Colors.white,
                        size: widget.iconSize ?? 40,
                      ),
                      onPressed: () {
                        final pos = _player.position;
                        _player.seek(pos + const Duration(seconds: 10));
                      },
                    ),
                  ],
                ),

                // Seekbar & times
                StreamBuilder<PositionData>(
                  stream: _positionDataStream,
                  builder: (context, snapshot) {
                    final data = snapshot.data;
                    final position = data?.position ?? Duration.zero;
                    final duration = data?.duration ?? Duration.zero;

                    return Column(
                      children: [
                        Slider(
                          min: 0.0,
                          max: duration.inMilliseconds.toDouble(),
                          value: position.inMilliseconds.toDouble(),
                          onChanged: (val) {
                            _player.seek(Duration(milliseconds: val.round()));
                          },
                        ),
                        Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 16.0),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Text(
                                _formatDuration(position),
                                style: const TextStyle(color: Colors.white),
                              ),
                              Text(
                                _formatDuration(duration),
                                style: const TextStyle(color: Colors.white),
                              ),
                            ],
                          ),
                        ),
                      ],
                    );
                  },
                ),
              ],
            ),
        ],
      ),
    );
  }
}

/// Simple data class with position, bufferedPosition, and total duration
class PositionData {
  final Duration position;
  final Duration bufferedPosition;
  final Duration duration;
  PositionData(this.position, this.bufferedPosition, this.duration);
}
