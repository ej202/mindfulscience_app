import 'dart:convert';
import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:intl/intl.dart';
import 'package:timeago/timeago.dart' as timeago;
import 'lat_lng.dart';
import 'place.dart';
import 'uploaded_file.dart';
import '/backend/backend.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import '/backend/schema/structs/index.dart';
import '/auth/firebase_auth/auth_util.dart';

String? getGreetingMessage(int? currentHour) {
  if (currentHour == null) {
    return "Hello"; // Default message if time is null
  }

  // Convert UNIX timestamp to DateTime
  DateTime localTime =
      DateTime.fromMillisecondsSinceEpoch(currentHour * 1000).toLocal();
  int hour = localTime.hour; // Extract the local hour

  if (hour >= 0 && hour < 12) {
    return "Buenos días"; // 12:00 AM - 11:59 AM
  } else if (hour >= 12 && hour < 19) {
    return "Buenas tardes"; // 12:00 PM - 6:59 PM
  } else {
    return "Buenas noches"; // 7:00 PM - 11:59 PM
  }
}

int? getDayOfYear() {
  int getDayOfYear() {
    final now = DateTime.now().toUtc(); // or local if you prefer
    return int.parse(DateFormat("D").format(now));
  }
}
