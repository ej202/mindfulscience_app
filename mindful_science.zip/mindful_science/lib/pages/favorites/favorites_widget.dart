import '';
import '/auth/firebase_auth/auth_util.dart';
import '/backend/backend.dart';
import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_toggle_icon.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'dart:ui';
import '/index.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'favorites_model.dart';
export 'favorites_model.dart';

class FavoritesWidget extends StatefulWidget {
  const FavoritesWidget({
    super.key,
    required this.coursetitle,
    required this.coursesessions,
    required this.courseimage,
    required this.courseid,
    required this.coursedescription,
    required this.singletitle,
    required this.singleduration,
    required this.singleid,
  });

  final String? coursetitle;
  final String? coursesessions;
  final String? courseimage;
  final int? courseid;
  final String? coursedescription;
  final String? singletitle;
  final String? singleduration;
  final int? singleid;

  static String routeName = 'favorites';
  static String routePath = '/favorites';

  @override
  State<FavoritesWidget> createState() => _FavoritesWidgetState();
}

class _FavoritesWidgetState extends State<FavoritesWidget> {
  late FavoritesModel _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => FavoritesModel());

    WidgetsBinding.instance.addPostFrameCallback((_) => safeSetState(() {}));
  }

  @override
  void dispose() {
    _model.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<List<UsersRecord>>(
      stream: queryUsersRecord(
        queryBuilder: (usersRecord) => usersRecord
            .where(
              'email',
              isEqualTo: currentUserEmail,
            )
            .where(
              'hasPremium',
              isEqualTo: true,
            ),
        singleRecord: true,
      ),
      builder: (context, snapshot) {
        // Customize what your widget looks like when it's loading.
        if (!snapshot.hasData) {
          return Scaffold(
            backgroundColor: FlutterFlowTheme.of(context).primaryBackground,
            body: Center(
              child: SizedBox(
                width: 50.0,
                height: 50.0,
                child: CircularProgressIndicator(
                  valueColor: AlwaysStoppedAnimation<Color>(
                    FlutterFlowTheme.of(context).primary,
                  ),
                ),
              ),
            ),
          );
        }
        List<UsersRecord> favoritesUsersRecordList = snapshot.data!;
        // Return an empty Container when the item does not exist.
        if (snapshot.data!.isEmpty) {
          return Container();
        }
        final favoritesUsersRecord = favoritesUsersRecordList.isNotEmpty
            ? favoritesUsersRecordList.first
            : null;

        return GestureDetector(
          onTap: () {
            FocusScope.of(context).unfocus();
            FocusManager.instance.primaryFocus?.unfocus();
          },
          child: Scaffold(
            key: scaffoldKey,
            backgroundColor: FlutterFlowTheme.of(context).primaryBackground,
            body: Container(
              width: double.infinity,
              height: double.infinity,
              decoration: BoxDecoration(
                color: Color(0xFF2D5C94),
              ),
              child: SingleChildScrollView(
                primary: false,
                child: Column(
                  mainAxisSize: MainAxisSize.max,
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    Padding(
                      padding:
                          EdgeInsetsDirectional.fromSTEB(0.0, 0.0, 0.0, 20.0),
                      child: Container(
                        width: double.infinity,
                        height: 100.0,
                        decoration: BoxDecoration(
                          image: DecorationImage(
                            fit: BoxFit.cover,
                            image: Image.network(
                              widget!.courseimage!,
                            ).image,
                          ),
                        ),
                        child: Container(
                          width: double.infinity,
                          child: Stack(
                            children: [
                              Padding(
                                padding: EdgeInsetsDirectional.fromSTEB(
                                    0.0, 30.0, 0.0, 0.0),
                                child: Container(
                                  width: double.infinity,
                                  height: double.infinity,
                                  decoration: BoxDecoration(
                                    gradient: LinearGradient(
                                      colors: [
                                        Color(0x00FFFFFF),
                                        Color(0x002D5C94),
                                        Color(0xFF2D5C94)
                                      ],
                                      stops: [0.0, 0.88, 1.0],
                                      begin: AlignmentDirectional(0.0, -1.0),
                                      end: AlignmentDirectional(0, 1.0),
                                    ),
                                  ),
                                  child: Row(
                                    mainAxisSize: MainAxisSize.max,
                                    mainAxisAlignment: MainAxisAlignment.start,
                                    children: [
                                      Padding(
                                        padding: EdgeInsetsDirectional.fromSTEB(
                                            10.0, 10.0, 0.0, 0.0),
                                        child: FlutterFlowIconButton(
                                          borderRadius: 25.0,
                                          buttonSize: 50.0,
                                          fillColor: Color(0x25252323),
                                          icon: Icon(
                                            Icons.close_outlined,
                                            color: FlutterFlowTheme.of(context)
                                                .info,
                                            size: 24.0,
                                          ),
                                          onPressed: () async {
                                            context.safePop();
                                          },
                                        ),
                                      ),
                                      Padding(
                                        padding: EdgeInsetsDirectional.fromSTEB(
                                            0.0, 10.0, 0.0, 0.0),
                                        child: Text(
                                          'Tus favoritos',
                                          textAlign: TextAlign.center,
                                          style: FlutterFlowTheme.of(context)
                                              .titleLarge
                                              .override(
                                                fontFamily: 'Montserrat',
                                                color: Colors.white,
                                                letterSpacing: 0.0,
                                              ),
                                        ),
                                      ),
                                    ].divide(SizedBox(width: 85.0)),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                    Padding(
                      padding:
                          EdgeInsetsDirectional.fromSTEB(0.0, 30.0, 0.0, 0.0),
                      child: Container(
                        width: 100.0,
                        decoration: BoxDecoration(
                          gradient: LinearGradient(
                            colors: [Color(0xFF2D5C94), Color(0xFF2D5C94)],
                            stops: [0.0, 0.25],
                            begin: AlignmentDirectional(0.0, -1.0),
                            end: AlignmentDirectional(0, 1.0),
                          ),
                        ),
                        child: Visibility(
                          visible:
                              (currentUserDocument?.favoriteCourses?.toList() ??
                                      [])
                                  .isNotEmpty,
                          child: AuthUserStreamWidget(
                            builder: (context) =>
                                StreamBuilder<List<CoursesRecord>>(
                              stream: queryCoursesRecord(
                                queryBuilder: (coursesRecord) =>
                                    coursesRecord.whereIn(
                                        'courseid',
                                        (currentUserDocument?.favoriteCourses
                                                ?.toList() ??
                                            [])),
                              ),
                              builder: (context, snapshot) {
                                // Customize what your widget looks like when it's loading.
                                if (!snapshot.hasData) {
                                  return Center(
                                    child: SizedBox(
                                      width: 50.0,
                                      height: 50.0,
                                      child: CircularProgressIndicator(
                                        valueColor:
                                            AlwaysStoppedAnimation<Color>(
                                          FlutterFlowTheme.of(context).primary,
                                        ),
                                      ),
                                    ),
                                  );
                                }
                                List<CoursesRecord>
                                    section3aListViewCoursesRecordList =
                                    snapshot.data!;

                                return ListView.builder(
                                  padding: EdgeInsets.zero,
                                  primary: false,
                                  shrinkWrap: true,
                                  scrollDirection: Axis.vertical,
                                  itemCount:
                                      section3aListViewCoursesRecordList.length,
                                  itemBuilder:
                                      (context, section3aListViewIndex) {
                                    final section3aListViewCoursesRecord =
                                        section3aListViewCoursesRecordList[
                                            section3aListViewIndex];
                                    return Padding(
                                      padding: EdgeInsetsDirectional.fromSTEB(
                                          20.0, 0.0, 20.0, 10.0),
                                      child: InkWell(
                                        splashColor: Colors.transparent,
                                        focusColor: Colors.transparent,
                                        hoverColor: Colors.transparent,
                                        highlightColor: Colors.transparent,
                                        onTap: () async {
                                          if (favoritesUsersRecord!
                                              .hasPremium) {
                                            context.pushNamed(
                                              LessonsPageWidget.routeName,
                                              queryParameters: {
                                                'coursetitle': serializeParam(
                                                  section3aListViewCoursesRecord
                                                      .courseTitle,
                                                  ParamType.String,
                                                ),
                                                'coursesessions':
                                                    serializeParam(
                                                  section3aListViewCoursesRecord
                                                      .courseSessions,
                                                  ParamType.String,
                                                ),
                                                'courseimage': serializeParam(
                                                  section3aListViewCoursesRecord
                                                      .courseImageUrl,
                                                  ParamType.String,
                                                ),
                                                'courseid': serializeParam(
                                                  section3aListViewCoursesRecord
                                                      .courseid,
                                                  ParamType.int,
                                                ),
                                                'coursedescription':
                                                    serializeParam(
                                                  section3aListViewCoursesRecord
                                                      .courseDescription,
                                                  ParamType.String,
                                                ),
                                                'collectionType':
                                                    serializeParam(
                                                  'lesson',
                                                  ParamType.String,
                                                ),
                                              }.withoutNulls,
                                            );
                                          } else {
                                            if (section3aListViewCoursesRecord
                                                .isLocked) {
                                              context.pushNamed(
                                                  PaywallWidget.routeName);
                                            } else {
                                              context.pushNamed(
                                                LessonsPageWidget.routeName,
                                                queryParameters: {
                                                  'coursetitle': serializeParam(
                                                    section3aListViewCoursesRecord
                                                        .courseTitle,
                                                    ParamType.String,
                                                  ),
                                                  'coursesessions':
                                                      serializeParam(
                                                    section3aListViewCoursesRecord
                                                        .courseSessions,
                                                    ParamType.String,
                                                  ),
                                                  'courseimage': serializeParam(
                                                    section3aListViewCoursesRecord
                                                        .courseImageUrl,
                                                    ParamType.String,
                                                  ),
                                                  'courseid': serializeParam(
                                                    section3aListViewCoursesRecord
                                                        .courseid,
                                                    ParamType.int,
                                                  ),
                                                  'coursedescription':
                                                      serializeParam(
                                                    section3aListViewCoursesRecord
                                                        .courseDescription,
                                                    ParamType.String,
                                                  ),
                                                  'collectionType':
                                                      serializeParam(
                                                    'lesson',
                                                    ParamType.String,
                                                  ),
                                                }.withoutNulls,
                                              );
                                            }
                                          }
                                        },
                                        child: Container(
                                          width: 100.0,
                                          height: 100.0,
                                          decoration: BoxDecoration(
                                            color: Color(0xFF164988),
                                            borderRadius:
                                                BorderRadius.circular(12.0),
                                          ),
                                          child: Row(
                                            mainAxisSize: MainAxisSize.max,
                                            children: [
                                              Column(
                                                mainAxisSize: MainAxisSize.max,
                                                children: [
                                                  Container(
                                                    width: 100.0,
                                                    height: 100.0,
                                                    decoration: BoxDecoration(),
                                                    child: Stack(
                                                      children: [
                                                        Padding(
                                                          padding:
                                                              EdgeInsetsDirectional
                                                                  .fromSTEB(
                                                                      10.0,
                                                                      10.0,
                                                                      10.0,
                                                                      10.0),
                                                          child: ClipRRect(
                                                            borderRadius:
                                                                BorderRadius
                                                                    .circular(
                                                                        8.0),
                                                            child:
                                                                Image.network(
                                                              section3aListViewCoursesRecord
                                                                  .courseImageUrl,
                                                              width: 200.0,
                                                              height: 200.0,
                                                              fit: BoxFit.cover,
                                                            ),
                                                          ),
                                                        ),
                                                        if (!favoritesUsersRecord!
                                                                .hasPremium &&
                                                            section3aListViewCoursesRecord
                                                                .isLocked)
                                                          Align(
                                                            alignment:
                                                                AlignmentDirectional(
                                                                    -1.0, 1.0),
                                                            child: Padding(
                                                              padding:
                                                                  EdgeInsetsDirectional
                                                                      .fromSTEB(
                                                                          15.0,
                                                                          0.0,
                                                                          0.0,
                                                                          15.0),
                                                              child: Container(
                                                                width: 30.0,
                                                                height: 30.0,
                                                                decoration:
                                                                    BoxDecoration(
                                                                  color: Color(
                                                                      0x7B000000),
                                                                  borderRadius:
                                                                      BorderRadius
                                                                          .circular(
                                                                              25.0),
                                                                ),
                                                                child: Icon(
                                                                  Icons
                                                                      .lock_outline_sharp,
                                                                  color: Colors
                                                                      .white,
                                                                  size: 18.0,
                                                                ),
                                                              ),
                                                            ),
                                                          ),
                                                      ],
                                                    ),
                                                  ),
                                                ],
                                              ),
                                              Padding(
                                                padding: EdgeInsetsDirectional
                                                    .fromSTEB(
                                                        5.0, 0.0, 0.0, 0.0),
                                                child: Column(
                                                  mainAxisSize:
                                                      MainAxisSize.max,
                                                  children: [
                                                    Padding(
                                                      padding:
                                                          EdgeInsetsDirectional
                                                              .fromSTEB(
                                                                  0.0,
                                                                  5.0,
                                                                  0.0,
                                                                  0.0),
                                                      child: Container(
                                                        width: 270.0,
                                                        height: 30.0,
                                                        decoration:
                                                            BoxDecoration(),
                                                        child: Row(
                                                          mainAxisSize:
                                                              MainAxisSize.max,
                                                          children: [
                                                            Text(
                                                              section3aListViewCoursesRecord
                                                                  .courseTitle,
                                                              style: FlutterFlowTheme
                                                                      .of(context)
                                                                  .bodyMedium
                                                                  .override(
                                                                    fontFamily:
                                                                        'Montserrat',
                                                                    color: Colors
                                                                        .white,
                                                                    fontSize:
                                                                        16.0,
                                                                    letterSpacing:
                                                                        0.0,
                                                                    fontWeight:
                                                                        FontWeight
                                                                            .w500,
                                                                  ),
                                                            ),
                                                            Expanded(
                                                              child: Align(
                                                                alignment:
                                                                    AlignmentDirectional(
                                                                        1.0,
                                                                        -1.0),
                                                                child:
                                                                    ToggleIcon(
                                                                  onPressed:
                                                                      () async {
                                                                    final favoriteCoursesElement =
                                                                        section3aListViewCoursesRecord
                                                                            .courseid;
                                                                    final favoriteCoursesUpdate = favoritesUsersRecord!
                                                                            .favoriteCourses
                                                                            .contains(
                                                                                favoriteCoursesElement)
                                                                        ? FieldValue
                                                                            .arrayRemove([
                                                                            favoriteCoursesElement
                                                                          ])
                                                                        : FieldValue
                                                                            .arrayUnion([
                                                                            favoriteCoursesElement
                                                                          ]);
                                                                    await favoritesUsersRecord!
                                                                        .reference
                                                                        .update({
                                                                      ...mapToFirestore(
                                                                        {
                                                                          'favorite_courses':
                                                                              favoriteCoursesUpdate,
                                                                        },
                                                                      ),
                                                                    });
                                                                    if ((currentUserDocument?.favoriteCourses?.toList() ??
                                                                            [])
                                                                        .contains(
                                                                            section3aListViewCoursesRecord.courseid)) {
                                                                      await currentUserReference!
                                                                          .update({
                                                                        ...mapToFirestore(
                                                                          {
                                                                            'favorite_courses':
                                                                                FieldValue.arrayRemove([
                                                                              section3aListViewCoursesRecord.courseid
                                                                            ]),
                                                                          },
                                                                        ),
                                                                      });
                                                                    } else {
                                                                      return;
                                                                    }
                                                                  },
                                                                  value: favoritesUsersRecord!
                                                                      .favoriteCourses
                                                                      .contains(
                                                                          section3aListViewCoursesRecord
                                                                              .courseid),
                                                                  onIcon: Icon(
                                                                    Icons
                                                                        .favorite_outlined,
                                                                    color: Colors
                                                                        .white,
                                                                    size: 24.0,
                                                                  ),
                                                                  offIcon: Icon(
                                                                    Icons
                                                                        .favorite_border_outlined,
                                                                    color: Colors
                                                                        .white,
                                                                    size: 24.0,
                                                                  ),
                                                                ),
                                                              ),
                                                            ),
                                                          ],
                                                        ),
                                                      ),
                                                    ),
                                                    Container(
                                                      width: 270.0,
                                                      height: 20.0,
                                                      decoration:
                                                          BoxDecoration(),
                                                      child: Align(
                                                        alignment:
                                                            AlignmentDirectional(
                                                                -1.0, -1.0),
                                                        child: Text(
                                                          section3aListViewCoursesRecord
                                                              .courseSessions,
                                                          style: FlutterFlowTheme
                                                                  .of(context)
                                                              .bodyMedium
                                                              .override(
                                                                fontFamily:
                                                                    'Montserrat',
                                                                color: Colors
                                                                    .white,
                                                                fontSize: 12.0,
                                                                letterSpacing:
                                                                    0.0,
                                                                fontWeight:
                                                                    FontWeight
                                                                        .w300,
                                                              ),
                                                        ),
                                                      ),
                                                    ),
                                                    Container(
                                                      width: 270.0,
                                                      height: 50.0,
                                                      decoration:
                                                          BoxDecoration(),
                                                      child: Stack(
                                                        children: [
                                                          Align(
                                                            alignment:
                                                                AlignmentDirectional(
                                                                    -1.0, -1.0),
                                                            child:
                                                                FFButtonWidget(
                                                              onPressed: () {
                                                                print(
                                                                    'Button pressed ...');
                                                              },
                                                              text: section3aListViewCoursesRecord
                                                                  .courseCategory,
                                                              options:
                                                                  FFButtonOptions(
                                                                height: 20.0,
                                                                padding: EdgeInsetsDirectional
                                                                    .fromSTEB(
                                                                        16.0,
                                                                        0.0,
                                                                        16.0,
                                                                        0.0),
                                                                iconPadding:
                                                                    EdgeInsetsDirectional
                                                                        .fromSTEB(
                                                                            0.0,
                                                                            0.0,
                                                                            0.0,
                                                                            0.0),
                                                                color: Color(
                                                                    0xFFF0CFAA),
                                                                textStyle: FlutterFlowTheme.of(
                                                                        context)
                                                                    .titleSmall
                                                                    .override(
                                                                      fontFamily:
                                                                          'Montserrat',
                                                                      color: Colors
                                                                          .black,
                                                                      fontSize:
                                                                          12.0,
                                                                      letterSpacing:
                                                                          0.0,
                                                                      fontWeight:
                                                                          FontWeight
                                                                              .normal,
                                                                    ),
                                                                elevation: 0.0,
                                                                borderRadius:
                                                                    BorderRadius
                                                                        .circular(
                                                                            8.0),
                                                              ),
                                                            ),
                                                          ),
                                                        ],
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                      ),
                                    );
                                  },
                                );
                              },
                            ),
                          ),
                        ),
                      ),
                    ),
                    Padding(
                      padding:
                          EdgeInsetsDirectional.fromSTEB(0.0, 30.0, 0.0, 0.0),
                      child: Container(
                        width: 100.0,
                        decoration: BoxDecoration(
                          gradient: LinearGradient(
                            colors: [Color(0xFF2D5C94), Color(0xFF2D5C94)],
                            stops: [0.0, 0.25],
                            begin: AlignmentDirectional(0.0, -1.0),
                            end: AlignmentDirectional(0, 1.0),
                          ),
                        ),
                        child: Visibility(
                          visible:
                              (currentUserDocument?.favoriteLessons?.toList() ??
                                      [])
                                  .isNotEmpty,
                          child: AuthUserStreamWidget(
                            builder: (context) =>
                                StreamBuilder<List<LessonsRecord>>(
                              stream: queryLessonsRecord(
                                queryBuilder: (lessonsRecord) =>
                                    lessonsRecord.whereIn(
                                        'lessonid',
                                        (currentUserDocument?.favoriteLessons
                                                ?.toList() ??
                                            [])),
                              ),
                              builder: (context, snapshot) {
                                // Customize what your widget looks like when it's loading.
                                if (!snapshot.hasData) {
                                  return Center(
                                    child: SizedBox(
                                      width: 50.0,
                                      height: 50.0,
                                      child: CircularProgressIndicator(
                                        valueColor:
                                            AlwaysStoppedAnimation<Color>(
                                          FlutterFlowTheme.of(context).primary,
                                        ),
                                      ),
                                    ),
                                  );
                                }
                                List<LessonsRecord>
                                    section3aListViewLessonsRecordList =
                                    snapshot.data!;

                                return ListView.builder(
                                  padding: EdgeInsets.zero,
                                  primary: false,
                                  shrinkWrap: true,
                                  scrollDirection: Axis.vertical,
                                  itemCount:
                                      section3aListViewLessonsRecordList.length,
                                  itemBuilder:
                                      (context, section3aListViewIndex) {
                                    final section3aListViewLessonsRecord =
                                        section3aListViewLessonsRecordList[
                                            section3aListViewIndex];
                                    return Padding(
                                      padding: EdgeInsetsDirectional.fromSTEB(
                                          20.0, 0.0, 20.0, 10.0),
                                      child: InkWell(
                                        splashColor: Colors.transparent,
                                        focusColor: Colors.transparent,
                                        hoverColor: Colors.transparent,
                                        highlightColor: Colors.transparent,
                                        onTap: () async {
                                          if (valueOrDefault<bool>(
                                              currentUserDocument?.hasPremium,
                                              false)) {
                                            context.pushNamed(
                                              LessonsPlayerPageWidget.routeName,
                                              queryParameters: {
                                                'lessontitle': serializeParam(
                                                  section3aListViewLessonsRecord
                                                      .lessonTitle,
                                                  ParamType.String,
                                                ),
                                                'lessonaudio': serializeParam(
                                                  section3aListViewLessonsRecord
                                                      .lessonAudioUrl,
                                                  ParamType.String,
                                                ),
                                                'courseimage': serializeParam(
                                                  section3aListViewLessonsRecord
                                                      .lessonImageUrl,
                                                  ParamType.String,
                                                ),
                                                'collectionType':
                                                    serializeParam(
                                                  'lesson',
                                                  ParamType.String,
                                                ),
                                              }.withoutNulls,
                                            );
                                          } else {
                                            if (section3aListViewLessonsRecord
                                                .isLocked) {
                                              context.pushNamed(
                                                  PaywallWidget.routeName);
                                            } else {
                                              context.pushNamed(
                                                LessonsPlayerPageWidget
                                                    .routeName,
                                                queryParameters: {
                                                  'lessontitle': serializeParam(
                                                    section3aListViewLessonsRecord
                                                        .lessonTitle,
                                                    ParamType.String,
                                                  ),
                                                  'lessonaudio': serializeParam(
                                                    section3aListViewLessonsRecord
                                                        .lessonAudioUrl,
                                                    ParamType.String,
                                                  ),
                                                  'courseimage': serializeParam(
                                                    section3aListViewLessonsRecord
                                                        .lessonImageUrl,
                                                    ParamType.String,
                                                  ),
                                                  'collectionType':
                                                      serializeParam(
                                                    'single',
                                                    ParamType.String,
                                                  ),
                                                }.withoutNulls,
                                              );
                                            }
                                          }
                                        },
                                        child: Container(
                                          width: 100.0,
                                          height: 100.0,
                                          decoration: BoxDecoration(
                                            color: Color(0xFF164988),
                                            borderRadius:
                                                BorderRadius.circular(12.0),
                                          ),
                                          child: Row(
                                            mainAxisSize: MainAxisSize.max,
                                            children: [
                                              Column(
                                                mainAxisSize: MainAxisSize.max,
                                                children: [
                                                  Container(
                                                    width: 100.0,
                                                    height: 100.0,
                                                    decoration: BoxDecoration(),
                                                    child: Stack(
                                                      children: [
                                                        Padding(
                                                          padding:
                                                              EdgeInsetsDirectional
                                                                  .fromSTEB(
                                                                      10.0,
                                                                      10.0,
                                                                      10.0,
                                                                      10.0),
                                                          child: ClipRRect(
                                                            borderRadius:
                                                                BorderRadius
                                                                    .circular(
                                                                        8.0),
                                                            child:
                                                                Image.network(
                                                              section3aListViewLessonsRecord
                                                                  .lessonImageUrl,
                                                              width: 200.0,
                                                              height: 200.0,
                                                              fit: BoxFit.cover,
                                                            ),
                                                          ),
                                                        ),
                                                        if (!favoritesUsersRecord!
                                                                .hasPremium &&
                                                            section3aListViewLessonsRecord
                                                                .isLocked)
                                                          Align(
                                                            alignment:
                                                                AlignmentDirectional(
                                                                    -1.0, 1.0),
                                                            child: Padding(
                                                              padding:
                                                                  EdgeInsetsDirectional
                                                                      .fromSTEB(
                                                                          15.0,
                                                                          0.0,
                                                                          0.0,
                                                                          15.0),
                                                              child: Container(
                                                                width: 30.0,
                                                                height: 30.0,
                                                                decoration:
                                                                    BoxDecoration(
                                                                  color: Color(
                                                                      0x7B000000),
                                                                  borderRadius:
                                                                      BorderRadius
                                                                          .circular(
                                                                              25.0),
                                                                ),
                                                                child: Icon(
                                                                  Icons
                                                                      .lock_outline_sharp,
                                                                  color: Colors
                                                                      .white,
                                                                  size: 18.0,
                                                                ),
                                                              ),
                                                            ),
                                                          ),
                                                      ],
                                                    ),
                                                  ),
                                                ],
                                              ),
                                              Padding(
                                                padding: EdgeInsetsDirectional
                                                    .fromSTEB(
                                                        5.0, 0.0, 0.0, 0.0),
                                                child: Column(
                                                  mainAxisSize:
                                                      MainAxisSize.max,
                                                  children: [
                                                    Padding(
                                                      padding:
                                                          EdgeInsetsDirectional
                                                              .fromSTEB(
                                                                  0.0,
                                                                  5.0,
                                                                  0.0,
                                                                  0.0),
                                                      child: Container(
                                                        width: 270.0,
                                                        height: 30.0,
                                                        decoration:
                                                            BoxDecoration(),
                                                        child: Row(
                                                          mainAxisSize:
                                                              MainAxisSize.max,
                                                          children: [
                                                            Text(
                                                              valueOrDefault<
                                                                  String>(
                                                                section3aListViewLessonsRecord
                                                                    .lessonTitle,
                                                                'lessontitle',
                                                              ),
                                                              style: FlutterFlowTheme
                                                                      .of(context)
                                                                  .bodyMedium
                                                                  .override(
                                                                    fontFamily:
                                                                        'Montserrat',
                                                                    color: Colors
                                                                        .white,
                                                                    fontSize:
                                                                        16.0,
                                                                    letterSpacing:
                                                                        0.0,
                                                                    fontWeight:
                                                                        FontWeight
                                                                            .w500,
                                                                  ),
                                                            ),
                                                            Expanded(
                                                              child: Align(
                                                                alignment:
                                                                    AlignmentDirectional(
                                                                        1.0,
                                                                        -1.0),
                                                                child:
                                                                    ToggleIcon(
                                                                  onPressed:
                                                                      () async {
                                                                    final favoriteLessonsElement =
                                                                        section3aListViewLessonsRecord
                                                                            .lessonid;
                                                                    final favoriteLessonsUpdate = favoritesUsersRecord!
                                                                            .favoriteLessons
                                                                            .contains(
                                                                                favoriteLessonsElement)
                                                                        ? FieldValue
                                                                            .arrayRemove([
                                                                            favoriteLessonsElement
                                                                          ])
                                                                        : FieldValue
                                                                            .arrayUnion([
                                                                            favoriteLessonsElement
                                                                          ]);
                                                                    await favoritesUsersRecord!
                                                                        .reference
                                                                        .update({
                                                                      ...mapToFirestore(
                                                                        {
                                                                          'favorite_lessons':
                                                                              favoriteLessonsUpdate,
                                                                        },
                                                                      ),
                                                                    });
                                                                    if ((currentUserDocument?.favoriteSingles?.toList() ??
                                                                            [])
                                                                        .contains(
                                                                            section3aListViewLessonsRecord.lessonid)) {
                                                                      await currentUserReference!
                                                                          .update({
                                                                        ...mapToFirestore(
                                                                          {
                                                                            'favorite_singles':
                                                                                FieldValue.arrayRemove([
                                                                              section3aListViewLessonsRecord.lessonid
                                                                            ]),
                                                                          },
                                                                        ),
                                                                      });
                                                                    } else {
                                                                      return;
                                                                    }
                                                                  },
                                                                  value: favoritesUsersRecord!
                                                                      .favoriteLessons
                                                                      .contains(
                                                                          section3aListViewLessonsRecord
                                                                              .lessonid),
                                                                  onIcon: Icon(
                                                                    Icons
                                                                        .favorite_outlined,
                                                                    color: Colors
                                                                        .white,
                                                                    size: 24.0,
                                                                  ),
                                                                  offIcon: Icon(
                                                                    Icons
                                                                        .favorite_border_outlined,
                                                                    color: Colors
                                                                        .white,
                                                                    size: 24.0,
                                                                  ),
                                                                ),
                                                              ),
                                                            ),
                                                          ],
                                                        ),
                                                      ),
                                                    ),
                                                    Container(
                                                      width: 270.0,
                                                      height: 20.0,
                                                      decoration:
                                                          BoxDecoration(),
                                                      child: Align(
                                                        alignment:
                                                            AlignmentDirectional(
                                                                -1.0, -1.0),
                                                        child: Text(
                                                          section3aListViewLessonsRecord
                                                              .lessonDuration,
                                                          style: FlutterFlowTheme
                                                                  .of(context)
                                                              .bodyMedium
                                                              .override(
                                                                fontFamily:
                                                                    'Montserrat',
                                                                color: Colors
                                                                    .white,
                                                                fontSize: 12.0,
                                                                letterSpacing:
                                                                    0.0,
                                                                fontWeight:
                                                                    FontWeight
                                                                        .w300,
                                                              ),
                                                        ),
                                                      ),
                                                    ),
                                                    Container(
                                                      width: 270.0,
                                                      height: 50.0,
                                                      decoration:
                                                          BoxDecoration(),
                                                      child: Stack(
                                                        children: [
                                                          Align(
                                                            alignment:
                                                                AlignmentDirectional(
                                                                    -1.0, -1.0),
                                                            child:
                                                                FFButtonWidget(
                                                              onPressed: () {
                                                                print(
                                                                    'Button pressed ...');
                                                              },
                                                              text: section3aListViewLessonsRecord
                                                                  .lessonCategory,
                                                              options:
                                                                  FFButtonOptions(
                                                                height: 20.0,
                                                                padding: EdgeInsetsDirectional
                                                                    .fromSTEB(
                                                                        16.0,
                                                                        0.0,
                                                                        16.0,
                                                                        0.0),
                                                                iconPadding:
                                                                    EdgeInsetsDirectional
                                                                        .fromSTEB(
                                                                            0.0,
                                                                            0.0,
                                                                            0.0,
                                                                            0.0),
                                                                color: Color(
                                                                    0xFF769BC8),
                                                                textStyle: FlutterFlowTheme.of(
                                                                        context)
                                                                    .titleSmall
                                                                    .override(
                                                                      fontFamily:
                                                                          'Montserrat',
                                                                      color: Color(
                                                                          0xFF164988),
                                                                      fontSize:
                                                                          12.0,
                                                                      letterSpacing:
                                                                          0.0,
                                                                      fontWeight:
                                                                          FontWeight
                                                                              .w500,
                                                                    ),
                                                                elevation: 0.0,
                                                                borderRadius:
                                                                    BorderRadius
                                                                        .circular(
                                                                            8.0),
                                                              ),
                                                            ),
                                                          ),
                                                        ],
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                      ),
                                    );
                                  },
                                );
                              },
                            ),
                          ),
                        ),
                      ),
                    ),
                    Padding(
                      padding:
                          EdgeInsetsDirectional.fromSTEB(0.0, 30.0, 0.0, 0.0),
                      child: Container(
                        width: 100.0,
                        height: MediaQuery.sizeOf(context).height * 1.0,
                        decoration: BoxDecoration(
                          gradient: LinearGradient(
                            colors: [Color(0xFF2D5C94), Color(0xFF587AA3)],
                            stops: [0.0, 0.25],
                            begin: AlignmentDirectional(0.0, -1.0),
                            end: AlignmentDirectional(0, 1.0),
                          ),
                        ),
                        child: Visibility(
                          visible:
                              (currentUserDocument?.favoriteSingles?.toList() ??
                                      [])
                                  .isNotEmpty,
                          child: AuthUserStreamWidget(
                            builder: (context) =>
                                StreamBuilder<List<SinglesRecord>>(
                              stream: querySinglesRecord(
                                queryBuilder: (singlesRecord) =>
                                    singlesRecord.whereIn(
                                        'singleID',
                                        (currentUserDocument?.favoriteSingles
                                                ?.toList() ??
                                            [])),
                              ),
                              builder: (context, snapshot) {
                                // Customize what your widget looks like when it's loading.
                                if (!snapshot.hasData) {
                                  return Center(
                                    child: SizedBox(
                                      width: 50.0,
                                      height: 50.0,
                                      child: CircularProgressIndicator(
                                        valueColor:
                                            AlwaysStoppedAnimation<Color>(
                                          FlutterFlowTheme.of(context).primary,
                                        ),
                                      ),
                                    ),
                                  );
                                }
                                List<SinglesRecord>
                                    section3aListViewSinglesRecordList =
                                    snapshot.data!;

                                return ListView.builder(
                                  padding: EdgeInsets.zero,
                                  primary: false,
                                  shrinkWrap: true,
                                  scrollDirection: Axis.vertical,
                                  itemCount:
                                      section3aListViewSinglesRecordList.length,
                                  itemBuilder:
                                      (context, section3aListViewIndex) {
                                    final section3aListViewSinglesRecord =
                                        section3aListViewSinglesRecordList[
                                            section3aListViewIndex];
                                    return Padding(
                                      padding: EdgeInsetsDirectional.fromSTEB(
                                          20.0, 0.0, 20.0, 10.0),
                                      child: InkWell(
                                        splashColor: Colors.transparent,
                                        focusColor: Colors.transparent,
                                        hoverColor: Colors.transparent,
                                        highlightColor: Colors.transparent,
                                        onTap: () async {
                                          if (valueOrDefault<bool>(
                                              currentUserDocument?.hasPremium,
                                              false)) {
                                            context.pushNamed(
                                              LessonsPlayerPageWidget.routeName,
                                              queryParameters: {
                                                'lessontitle': serializeParam(
                                                  section3aListViewSinglesRecord
                                                      .singletitle,
                                                  ParamType.String,
                                                ),
                                                'lessonaudio': serializeParam(
                                                  section3aListViewSinglesRecord
                                                      .lessonAudioUrl,
                                                  ParamType.String,
                                                ),
                                                'courseimage': serializeParam(
                                                  section3aListViewSinglesRecord
                                                      .singleImageUrl,
                                                  ParamType.String,
                                                ),
                                                'collectionType':
                                                    serializeParam(
                                                  'single',
                                                  ParamType.String,
                                                ),
                                              }.withoutNulls,
                                            );
                                          } else {
                                            if (section3aListViewSinglesRecord
                                                .isLocked) {
                                              context.pushNamed(
                                                  PaywallWidget.routeName);
                                            } else {
                                              context.pushNamed(
                                                LessonsPlayerPageWidget
                                                    .routeName,
                                                queryParameters: {
                                                  'lessontitle': serializeParam(
                                                    section3aListViewSinglesRecord
                                                        .singletitle,
                                                    ParamType.String,
                                                  ),
                                                  'lessonaudio': serializeParam(
                                                    section3aListViewSinglesRecord
                                                        .lessonAudioUrl,
                                                    ParamType.String,
                                                  ),
                                                  'courseimage': serializeParam(
                                                    section3aListViewSinglesRecord
                                                        .singleImageUrl,
                                                    ParamType.String,
                                                  ),
                                                  'collectionType':
                                                      serializeParam(
                                                    'single',
                                                    ParamType.String,
                                                  ),
                                                }.withoutNulls,
                                              );
                                            }
                                          }
                                        },
                                        child: Container(
                                          width: 100.0,
                                          height: 100.0,
                                          decoration: BoxDecoration(
                                            color: Color(0xFF164988),
                                            borderRadius:
                                                BorderRadius.circular(12.0),
                                          ),
                                          child: Row(
                                            mainAxisSize: MainAxisSize.max,
                                            children: [
                                              Column(
                                                mainAxisSize: MainAxisSize.max,
                                                children: [
                                                  Container(
                                                    width: 100.0,
                                                    height: 100.0,
                                                    decoration: BoxDecoration(),
                                                    child: Stack(
                                                      children: [
                                                        Padding(
                                                          padding:
                                                              EdgeInsetsDirectional
                                                                  .fromSTEB(
                                                                      10.0,
                                                                      10.0,
                                                                      10.0,
                                                                      10.0),
                                                          child: ClipRRect(
                                                            borderRadius:
                                                                BorderRadius
                                                                    .circular(
                                                                        8.0),
                                                            child:
                                                                Image.network(
                                                              section3aListViewSinglesRecord
                                                                  .singleImageUrl,
                                                              width: 200.0,
                                                              height: 200.0,
                                                              fit: BoxFit.cover,
                                                            ),
                                                          ),
                                                        ),
                                                        if (!favoritesUsersRecord!
                                                                .hasPremium &&
                                                            section3aListViewSinglesRecord
                                                                .isLocked)
                                                          Align(
                                                            alignment:
                                                                AlignmentDirectional(
                                                                    -1.0, 1.0),
                                                            child: Padding(
                                                              padding:
                                                                  EdgeInsetsDirectional
                                                                      .fromSTEB(
                                                                          15.0,
                                                                          0.0,
                                                                          0.0,
                                                                          15.0),
                                                              child: Container(
                                                                width: 30.0,
                                                                height: 30.0,
                                                                decoration:
                                                                    BoxDecoration(
                                                                  color: Color(
                                                                      0x7B000000),
                                                                  borderRadius:
                                                                      BorderRadius
                                                                          .circular(
                                                                              25.0),
                                                                ),
                                                                child: Icon(
                                                                  Icons
                                                                      .lock_outline_sharp,
                                                                  color: Colors
                                                                      .white,
                                                                  size: 18.0,
                                                                ),
                                                              ),
                                                            ),
                                                          ),
                                                      ],
                                                    ),
                                                  ),
                                                ],
                                              ),
                                              Padding(
                                                padding: EdgeInsetsDirectional
                                                    .fromSTEB(
                                                        5.0, 0.0, 0.0, 0.0),
                                                child: Column(
                                                  mainAxisSize:
                                                      MainAxisSize.max,
                                                  children: [
                                                    Padding(
                                                      padding:
                                                          EdgeInsetsDirectional
                                                              .fromSTEB(
                                                                  0.0,
                                                                  5.0,
                                                                  0.0,
                                                                  0.0),
                                                      child: Container(
                                                        width: 270.0,
                                                        height: 30.0,
                                                        decoration:
                                                            BoxDecoration(),
                                                        child: Row(
                                                          mainAxisSize:
                                                              MainAxisSize.max,
                                                          children: [
                                                            Text(
                                                              section3aListViewSinglesRecord
                                                                  .singletitle,
                                                              style: FlutterFlowTheme
                                                                      .of(context)
                                                                  .bodyMedium
                                                                  .override(
                                                                    fontFamily:
                                                                        'Montserrat',
                                                                    color: Colors
                                                                        .white,
                                                                    fontSize:
                                                                        16.0,
                                                                    letterSpacing:
                                                                        0.0,
                                                                    fontWeight:
                                                                        FontWeight
                                                                            .w500,
                                                                  ),
                                                            ),
                                                            Expanded(
                                                              child: Align(
                                                                alignment:
                                                                    AlignmentDirectional(
                                                                        1.0,
                                                                        -1.0),
                                                                child:
                                                                    ToggleIcon(
                                                                  onPressed:
                                                                      () async {
                                                                    final favoriteSinglesElement =
                                                                        section3aListViewSinglesRecord
                                                                            .singleID;
                                                                    final favoriteSinglesUpdate = favoritesUsersRecord!
                                                                            .favoriteSingles
                                                                            .contains(
                                                                                favoriteSinglesElement)
                                                                        ? FieldValue
                                                                            .arrayRemove([
                                                                            favoriteSinglesElement
                                                                          ])
                                                                        : FieldValue
                                                                            .arrayUnion([
                                                                            favoriteSinglesElement
                                                                          ]);
                                                                    await favoritesUsersRecord!
                                                                        .reference
                                                                        .update({
                                                                      ...mapToFirestore(
                                                                        {
                                                                          'favorite_singles':
                                                                              favoriteSinglesUpdate,
                                                                        },
                                                                      ),
                                                                    });
                                                                    if ((currentUserDocument?.favoriteSingles?.toList() ??
                                                                            [])
                                                                        .contains(
                                                                            section3aListViewSinglesRecord.singleID)) {
                                                                      await currentUserReference!
                                                                          .update({
                                                                        ...mapToFirestore(
                                                                          {
                                                                            'favorite_singles':
                                                                                FieldValue.arrayRemove([
                                                                              section3aListViewSinglesRecord.singleID
                                                                            ]),
                                                                          },
                                                                        ),
                                                                      });
                                                                    } else {
                                                                      return;
                                                                    }
                                                                  },
                                                                  value: favoritesUsersRecord!
                                                                      .favoriteSingles
                                                                      .contains(
                                                                          section3aListViewSinglesRecord
                                                                              .singleID),
                                                                  onIcon: Icon(
                                                                    Icons
                                                                        .favorite_outlined,
                                                                    color: Colors
                                                                        .white,
                                                                    size: 24.0,
                                                                  ),
                                                                  offIcon: Icon(
                                                                    Icons
                                                                        .favorite_border_outlined,
                                                                    color: Colors
                                                                        .white,
                                                                    size: 24.0,
                                                                  ),
                                                                ),
                                                              ),
                                                            ),
                                                          ],
                                                        ),
                                                      ),
                                                    ),
                                                    Container(
                                                      width: 270.0,
                                                      height: 20.0,
                                                      decoration:
                                                          BoxDecoration(),
                                                      child: Align(
                                                        alignment:
                                                            AlignmentDirectional(
                                                                -1.0, -1.0),
                                                        child: Text(
                                                          section3aListViewSinglesRecord
                                                              .singleDuration,
                                                          style: FlutterFlowTheme
                                                                  .of(context)
                                                              .bodyMedium
                                                              .override(
                                                                fontFamily:
                                                                    'Montserrat',
                                                                color: Colors
                                                                    .white,
                                                                fontSize: 12.0,
                                                                letterSpacing:
                                                                    0.0,
                                                                fontWeight:
                                                                    FontWeight
                                                                        .w300,
                                                              ),
                                                        ),
                                                      ),
                                                    ),
                                                    Container(
                                                      width: 270.0,
                                                      height: 50.0,
                                                      decoration:
                                                          BoxDecoration(),
                                                      child: Stack(
                                                        children: [
                                                          Align(
                                                            alignment:
                                                                AlignmentDirectional(
                                                                    -1.0, -1.0),
                                                            child:
                                                                FFButtonWidget(
                                                              onPressed: () {
                                                                print(
                                                                    'Button pressed ...');
                                                              },
                                                              text: section3aListViewSinglesRecord
                                                                  .singleCategory,
                                                              options:
                                                                  FFButtonOptions(
                                                                height: 20.0,
                                                                padding: EdgeInsetsDirectional
                                                                    .fromSTEB(
                                                                        16.0,
                                                                        0.0,
                                                                        16.0,
                                                                        0.0),
                                                                iconPadding:
                                                                    EdgeInsetsDirectional
                                                                        .fromSTEB(
                                                                            0.0,
                                                                            0.0,
                                                                            0.0,
                                                                            0.0),
                                                                color: Color(
                                                                    0xFF769BC8),
                                                                textStyle: FlutterFlowTheme.of(
                                                                        context)
                                                                    .titleSmall
                                                                    .override(
                                                                      fontFamily:
                                                                          'Montserrat',
                                                                      color: Color(
                                                                          0xFF164988),
                                                                      fontSize:
                                                                          12.0,
                                                                      letterSpacing:
                                                                          0.0,
                                                                      fontWeight:
                                                                          FontWeight
                                                                              .w500,
                                                                    ),
                                                                elevation: 0.0,
                                                                borderRadius:
                                                                    BorderRadius
                                                                        .circular(
                                                                            8.0),
                                                              ),
                                                            ),
                                                          ),
                                                        ],
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                      ),
                                    );
                                  },
                                );
                              },
                            ),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        );
      },
    );
  }
}
