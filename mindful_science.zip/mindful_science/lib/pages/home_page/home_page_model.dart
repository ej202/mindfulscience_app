import '';
import '/auth/firebase_auth/auth_util.dart';
import '/backend/backend.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_toggle_icon.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_video_player.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'dart:ui';
import '/flutter_flow/custom_functions.dart' as functions;
import '/flutter_flow/request_manager.dart';

import '/index.dart';
import 'home_page_widget.dart' show HomePageWidget;
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class HomePageModel extends FlutterFlowModel<HomePageWidget> {
  ///  Local state fields for this page.
  /// to store the title
  String? selectedTitle;

  /// to store the image URL
  String? selectedImageURL;

  bool isAudioPlayerVisible = false;

  bool isPlaying = true;

  String selectedAudioUrl = '';

  String? currentSoundName = '\"\"';

  List<String> userFavorites = [];
  void addToUserFavorites(String item) => userFavorites.add(item);
  void removeFromUserFavorites(String item) => userFavorites.remove(item);
  void removeAtIndexFromUserFavorites(int index) =>
      userFavorites.removeAt(index);
  void insertAtIndexInUserFavorites(int index, String item) =>
      userFavorites.insert(index, item);
  void updateUserFavoritesAtIndex(int index, Function(String) updateFn) =>
      userFavorites[index] = updateFn(userFavorites[index]);

  /// Query cache managers for this widget.

  final _coursesQhomeManager = StreamRequestManager<List<CoursesRecord>>();
  Stream<List<CoursesRecord>> coursesQhome({
    String? uniqueQueryKey,
    bool? overrideCache,
    required Stream<List<CoursesRecord>> Function() requestFn,
  }) =>
      _coursesQhomeManager.performRequest(
        uniqueQueryKey: uniqueQueryKey,
        overrideCache: overrideCache,
        requestFn: requestFn,
      );
  void clearCoursesQhomeCache() => _coursesQhomeManager.clear();
  void clearCoursesQhomeCacheKey(String? uniqueKey) =>
      _coursesQhomeManager.clearRequest(uniqueKey);

  final _singleshomeManager = StreamRequestManager<List<SinglesRecord>>();
  Stream<List<SinglesRecord>> singleshome({
    String? uniqueQueryKey,
    bool? overrideCache,
    required Stream<List<SinglesRecord>> Function() requestFn,
  }) =>
      _singleshomeManager.performRequest(
        uniqueQueryKey: uniqueQueryKey,
        overrideCache: overrideCache,
        requestFn: requestFn,
      );
  void clearSingleshomeCache() => _singleshomeManager.clear();
  void clearSingleshomeCacheKey(String? uniqueKey) =>
      _singleshomeManager.clearRequest(uniqueKey);

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {
    /// Dispose query cache managers for this widget.

    clearCoursesQhomeCache();

    clearSingleshomeCache();
  }
}
