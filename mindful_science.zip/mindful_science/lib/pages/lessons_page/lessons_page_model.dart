import '';
import '/auth/firebase_auth/auth_util.dart';
import '/backend/backend.dart';
import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_toggle_icon.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'dart:ui';
import '/index.dart';
import 'lessons_page_widget.dart' show LessonsPageWidget;
import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class LessonsPageModel extends FlutterFlowModel<LessonsPageWidget> {
  ///  Local state fields for this page.
  /// to store the title
  String? selectedTitle;

  /// to store the image URL
  String? selectedImageURL;

  bool isAudioPlayerVisible = false;

  bool isPlaying = true;

  String selectedAudioUrl = '';

  String? currentSoundName = '\"\"';

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
