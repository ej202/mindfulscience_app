import '';
import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'dart:ui';
import '/custom_code/widgets/index.dart' as custom_widgets;
import 'lessons_player_page_widget.dart' show LessonsPlayerPageWidget;
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class LessonsPlayerPageModel extends FlutterFlowModel<LessonsPlayerPageWidget> {
  ///  Local state fields for this page.
  /// to store the title
  String? selectedTitle;

  /// to store the image URL
  String? selectedImageURL;

  bool isAudioPlayerVisible = false;

  bool isPlaying = true;

  String selectedAudioUrl = '';

  String? currentSoundName = '\"\"';

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
